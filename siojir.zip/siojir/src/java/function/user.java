package function;
import function.fuser;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class user{
  public static List<fuser>getAllRecords(){
    List<fuser> list = new ArrayList<fuser>();

    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM user");
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
          fuser u = new fuser();
          u.setIduser(rs.getInt("id_user"));
          u.setNama(rs.getString("nama_lengkap"));
          u.setTempat(rs.getString("tempat_lahir"));
          u.setTanggal(rs.getString("tanggal_lahir"));
          u.setEmail(rs.getString("email"));
          u.setPassword(rs.getString("password"));
          u.setLevel(rs.getString("level"));
          list.add(u);
      }
    }catch(Exception e){
      System.out.println(e);
    }
return list;
  }
  
  public static int update(fuser u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("UPDATE user SET nama_lengkap=?,tempat_lahir=?,tanggal_lahir=?,email=?,password=?,level=? WHERE id_user=?");
      ps.setString(1, u.getNama());
      ps.setString(2, u.getTempat());
      ps.setString(3, u.getTanggal());
      ps.setString(4, u.getEmail());
      ps.setString(5, u.getPassword());
      ps.setString(6, u.getLevel());
      ps.setInt(7, u.getIduser());

      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static fuser getRecordById(int id){
    fuser u = null;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE id_user=?");
      ps.setInt(1, id);
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
        u = new fuser();
        u.setIduser(rs.getInt("id_user"));
        u.setNama(rs.getString("nama_lengkap"));
        u.setTempat(rs.getString("tempat_lahir"));
        u.setTanggal(rs.getString("tanggal_lahir"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setLevel(rs.getString("level"));
    }
    }catch(Exception e){
      System.out.println(e);}
    return u;
  }
  public static int delete(fuser u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("delete from user where id_user=?");
      ps.setInt(1, u.getIduser());
      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static int save(fuser u){
   int status = 0;
   try{
       Connection con = koneksi.getKoneksi();
       PreparedStatement ps = con.prepareStatement("INSERT INTO user (nama_lengkap,tempat_lahir,tanggal_lahir,email,password,level) VALUES (?,?,?,?,?,?)");
       ps.setString(1, u.getNama());
       ps.setString(2, u.getTempat());
       ps.setString(3, u.getTanggal());
       ps.setString(4, u.getEmail());
       ps.setString(5, u.getPassword());
       ps.setString(6, u.getLevel());
       status = ps.executeUpdate();
   }catch(Exception e){
       System.out.println(e);
   }
   return status;
  }
}
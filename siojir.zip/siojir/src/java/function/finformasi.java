package function;

public class finformasi{
    String informasi,tanggal,judul;
    int iduser,idinformasi;

    public String getInformasi() {
        return informasi;
    }

    public void setInformasi(String informasi) {
        this.informasi = informasi;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public int getIdinformasi() {
        return idinformasi;
    }

    public void setIdinformasi(int idinformasi) {
        this.idinformasi = idinformasi;
    }
}
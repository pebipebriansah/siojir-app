package function;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import function.ftips;
import java.text.SimpleDateFormat;
public class tips{
  public static List<ftips>getAllRecords(){
    List<ftips> list = new ArrayList<ftips>();
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM tips");
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
          ftips u = new ftips();
          u.setIdtips(rs.getInt("id_tips"));
          u.setIduser(rs.getInt("id_user"));
          u.setJudul(rs.getString("judul"));
          u.setTanggal(rs.getString("tanggal"));
          u.setTips(rs.getString("tips"));
          list.add(u);
      }
    }catch(Exception e){
      System.out.println(e);
    }
return list;
  }
  public static int update(ftips u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("UPDATE tips SET id_user=?,judul=?,tanggal=?,tips=? WHERE id_tips=?");
      ps.setInt(1, u.getIduser());
      ps.setString(2, u.getJudul());
      ps.setString(3, u.getTanggal());
      ps.setString(4, u.getTips());
      ps.setInt(5, u.getIdtips());
      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static ftips getRecordById(int id){
    ftips u = null;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM tips WHERE id_tips=?");
      ps.setInt(1, id);
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
        u = new ftips();
        u.setIdtips(rs.getInt("id_tips"));
        u.setIduser(rs.getInt("id_user"));
        u.setJudul(rs.getString("judul"));
        u.setTanggal(rs.getString("tanggal"));
        u.setTips(rs.getString("tips"));
        }
    }catch(Exception e){
      System.out.println(e);}
    return u;
  }
  public static int delete(ftips u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("delete from tips where id_tips=?");
      ps.setInt(1, u.getIdtips());
      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static int save(ftips u){
   Date tgl = new Date();
   SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
   String tanggal = sdf.format(tgl);
   int status = 0;
   try{
       Connection con = koneksi.getKoneksi();
       PreparedStatement ps = con.prepareStatement("INSERT INTO tips (id_user,judul,tanggal,tips) VALUES (?,?,?,?)");
       ps.setInt(1, u.getIduser());
       ps.setString(2, u.getJudul());
       ps.setString(3, tanggal);
       ps.setString(4, u.getTips());
       status = ps.executeUpdate();
   }catch(Exception e){
       System.out.println(e);
   }
   return status;
  }
}
package function;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import function.finformasi;
import java.text.SimpleDateFormat;
public class informasi{
  public static List<finformasi>getAllRecords(){
    List<finformasi> list = new ArrayList<finformasi>();
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM informasi");
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
          finformasi u = new finformasi();
          u.setIdinformasi(rs.getInt("id_informasi"));
          u.setIduser(rs.getInt("id_user"));
          u.setJudul(rs.getString("judul"));
          u.setTanggal(rs.getString("tanggal"));
          u.setInformasi(rs.getString("informasi"));
          list.add(u);
      }
    }catch(Exception e){
      System.out.println(e);
    }
return list;
  }
  public static int update(finformasi u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("UPDATE informasi SET id_user=?,judul=?,tanggal=?,informasi=? WHERE id_informasi=?");
      ps.setInt(1, u.getIduser());
      ps.setString(2, u.getJudul());
      ps.setString(3, u.getTanggal());
      ps.setString(4, u.getInformasi());
      ps.setInt(5, u.getIdinformasi());
      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static finformasi getRecordById(int id){
    finformasi u = null;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("SELECT * FROM informasi WHERE id_informasi=?");
      ps.setInt(1, id);
      ResultSet rs = ps.executeQuery();
      while(rs.next()){
        u = new finformasi();
        u.setIdinformasi(rs.getInt("id_informasi"));
        u.setIduser(rs.getInt("id_user"));
        u.setJudul(rs.getString("judul"));
        u.setTanggal(rs.getString("tanggal"));
        u.setInformasi(rs.getString("informasi"));
        }
    }catch(Exception e){
      System.out.println(e);}
    return u;
  }
  public static int delete(finformasi u){
    int status = 0;
    try{
      Connection con = koneksi.getKoneksi();
      PreparedStatement ps = con.prepareStatement("delete from informasi where id_informasi=?");
      ps.setInt(1, u.getIdinformasi());
      status = ps.executeUpdate();
    }catch(Exception e){
      System.out.println(e);
    }
    return status;
  }
  public static int save(finformasi u){
   java.util.Date tgl = new java.util.Date();
   SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
   String tanggal = sdf.format(tgl);
   int status = 0;
   try{
       Connection con = koneksi.getKoneksi();
       PreparedStatement ps = con.prepareStatement("INSERT INTO informasi (id_user,judul,tanggal,informasi) VALUES (?,?,?,?)");
       ps.setInt(1, u.getIduser());
       ps.setString(2, u.getJudul());
       ps.setString(3, tanggal);
       ps.setString(4, u.getInformasi());
       status = ps.executeUpdate();
   }catch(Exception e){
       System.out.println(e);
   }
   return status;
  }
}